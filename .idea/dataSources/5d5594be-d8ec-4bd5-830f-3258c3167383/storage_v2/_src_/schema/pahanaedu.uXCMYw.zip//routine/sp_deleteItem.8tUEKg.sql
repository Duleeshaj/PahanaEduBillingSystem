create
    definer = root@localhost procedure sp_deleteItem(IN p_item_id int)
BEGIN
    DELETE FROM items WHERE item_id = p_item_id;
    SELECT ROW_COUNT() AS affected;
END;

