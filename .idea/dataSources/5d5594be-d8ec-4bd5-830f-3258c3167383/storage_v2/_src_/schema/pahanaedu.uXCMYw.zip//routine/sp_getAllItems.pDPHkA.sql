create
    definer = root@localhost procedure sp_getAllItems()
BEGIN
    SELECT item_id, name, description, price, stock
    FROM items
    ORDER BY name ASC;
END;

