create
    definer = root@localhost procedure sp_addItem(IN p_name varchar(100), IN p_description text,
                                                  IN p_price decimal(10, 2), IN p_stock int)
BEGIN
    INSERT INTO items(name, description, price, stock)
    VALUES (p_name, p_description, p_price, p_stock);
    SELECT LAST_INSERT_ID() AS new_id;
END;

