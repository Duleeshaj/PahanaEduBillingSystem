create
    definer = root@localhost procedure sp_updateItem(IN p_item_id int, IN p_name varchar(100), IN p_description text,
                                                     IN p_price decimal(10, 2), IN p_stock int)
BEGIN
    UPDATE items
    SET name = p_name,
        description = p_description,
        price = p_price,
        stock = p_stock
    WHERE item_id = p_item_id;
    SELECT ROW_COUNT() AS affected;
END;

