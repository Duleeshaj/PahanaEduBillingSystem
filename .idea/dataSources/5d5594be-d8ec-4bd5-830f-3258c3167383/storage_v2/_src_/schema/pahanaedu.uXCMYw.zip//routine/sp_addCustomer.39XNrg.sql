create
    definer = root@localhost procedure sp_addCustomer(IN p_account_number int, IN p_name varchar(100),
                                                      IN p_address varchar(255), IN p_telephone varchar(20),
                                                      IN p_email varchar(120))
BEGIN
    INSERT INTO customers (account_number, name, address, telephone, email)
    VALUES (p_account_number, p_name, p_address, p_telephone, p_email);
END;

