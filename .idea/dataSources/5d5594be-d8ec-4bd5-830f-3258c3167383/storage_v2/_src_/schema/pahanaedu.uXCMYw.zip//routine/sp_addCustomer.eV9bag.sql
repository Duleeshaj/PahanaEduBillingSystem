create
    definer = root@localhost procedure sp_addCustomer(IN p_account_number int, IN p_name varchar(100),
                                                      IN p_address varchar(255), IN p_telephone varchar(20),
                                                      IN p_units int)
BEGIN
    IF EXISTS (SELECT 1 FROM customers WHERE account_number = p_account_number) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account number already exists';
    ELSE
        INSERT INTO customers(account_number, name, address, telephone, units_consumed)
        VALUES (p_account_number, p_name, p_address, p_telephone, p_units);
    END IF;
END;

