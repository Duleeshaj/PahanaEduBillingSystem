create
    definer = root@localhost procedure sp_addBill(IN p_account_number int, IN p_units_consumed int,
                                                  IN p_unit_rate decimal(10, 2), OUT p_bill_id int)
BEGIN
    DECLARE v_total DECIMAL(12,2);
    SET v_total = p_units_consumed * p_unit_rate;

    INSERT INTO bills (account_number, units_consumed, unit_rate, total_amount)
    VALUES (p_account_number, p_units_consumed, p_unit_rate, v_total);

    SET p_bill_id = LAST_INSERT_ID();
END;

