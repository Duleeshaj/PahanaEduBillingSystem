create
    definer = root@localhost procedure sp_updateCustomer(IN acc_no int, IN cust_name varchar(100),
                                                         IN cust_address varchar(255), IN cust_phone varchar(15),
                                                         IN units int)
BEGIN
    UPDATE customers
    SET name = cust_name,
        address = cust_address,
        telephone = cust_phone,
        units_consumed = units
    WHERE account_number = acc_no;

    -- Return how many rows were updated (0 means not found / no change)
    SELECT ROW_COUNT() AS affected_rows;
END;

