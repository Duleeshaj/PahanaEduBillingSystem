create
    definer = root@localhost procedure sp_getAllCustomers()
BEGIN
    SELECT account_number, name, address, telephone, units_consumed
    FROM customers
    ORDER BY name ASC;
END;

