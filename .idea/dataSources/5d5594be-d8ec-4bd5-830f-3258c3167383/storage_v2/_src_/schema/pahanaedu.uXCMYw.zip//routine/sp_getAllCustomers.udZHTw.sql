create
    definer = root@localhost procedure sp_getAllCustomers()
BEGIN
    SELECT *
    FROM customers
    ORDER BY account_number;
END;

