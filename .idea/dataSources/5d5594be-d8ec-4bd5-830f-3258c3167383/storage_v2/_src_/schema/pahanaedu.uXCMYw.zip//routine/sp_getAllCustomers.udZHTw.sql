create
    definer = root@localhost procedure sp_getAllCustomers()
BEGIN
    SELECT account_number, name, address, telephone, email
    FROM customers
    ORDER BY name ASC;
END;

