create
    definer = root@localhost procedure sp_addCustomer(IN acc_no int, IN cust_name varchar(100),
                                                      IN cust_address varchar(255), IN cust_phone varchar(15),
                                                      IN units int)
BEGIN
    INSERT INTO customers (account_number, name, address, telephone, units_consumed)
    VALUES (acc_no, cust_name, cust_address, cust_phone, units);
END;

