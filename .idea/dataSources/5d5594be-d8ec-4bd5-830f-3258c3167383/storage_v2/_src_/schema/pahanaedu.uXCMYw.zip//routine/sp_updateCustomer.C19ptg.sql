create
    definer = root@localhost procedure sp_updateCustomer(IN p_account_number int, IN p_name varchar(100),
                                                         IN p_address varchar(255), IN p_telephone varchar(20),
                                                         IN p_email varchar(120))
BEGIN
    UPDATE customers
    SET name = p_name,
        address = p_address,
        telephone = p_telephone,
        email = p_email
    WHERE account_number = p_account_number;
END;

