create definer = root@localhost trigger enforce_password_rule_update
    before update
    on users
    for each row
BEGIN
    IF NEW.role != 'customer' AND NEW.password IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Password is required for non-customer roles';
    END IF;
END;

