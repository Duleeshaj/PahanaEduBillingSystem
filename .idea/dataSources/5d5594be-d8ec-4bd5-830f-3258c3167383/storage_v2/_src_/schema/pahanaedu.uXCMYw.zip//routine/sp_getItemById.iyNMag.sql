create
    definer = root@localhost procedure sp_getItemById(IN p_item_id int)
BEGIN
    SELECT item_id, name, description, price, stock
    FROM items
    WHERE item_id = p_item_id;
END;

