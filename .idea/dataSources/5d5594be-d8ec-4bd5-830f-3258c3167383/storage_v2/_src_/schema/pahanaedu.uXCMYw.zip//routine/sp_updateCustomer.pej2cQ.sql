create
    definer = root@localhost procedure sp_updateCustomer(IN p_account_number int, IN p_name varchar(100),
                                                         IN p_address varchar(255), IN p_telephone varchar(20),
                                                         IN p_units int)
BEGIN
    UPDATE customers
    SET name = p_name,
        address = p_address,
        telephone = p_telephone,
        units_consumed = p_units
    WHERE account_number = p_account_number;

    IF ROW_COUNT() = 0 THEN
        SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'No such customer to update';
    END IF;
END;

