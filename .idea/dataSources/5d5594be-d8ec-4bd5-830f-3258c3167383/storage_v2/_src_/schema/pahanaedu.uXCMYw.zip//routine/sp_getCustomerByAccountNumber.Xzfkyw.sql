create
    definer = root@localhost procedure sp_getCustomerByAccountNumber(IN p_account_number int)
BEGIN
    SELECT account_number, name, address, telephone, email
    FROM customers
    WHERE account_number = p_account_number;
END;

