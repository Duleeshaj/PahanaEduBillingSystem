create
    definer = root@localhost procedure sp_getCustomerByAccountNumber(IN accNo int)
BEGIN
    SELECT * FROM customers WHERE account_number = accNo;
END;

