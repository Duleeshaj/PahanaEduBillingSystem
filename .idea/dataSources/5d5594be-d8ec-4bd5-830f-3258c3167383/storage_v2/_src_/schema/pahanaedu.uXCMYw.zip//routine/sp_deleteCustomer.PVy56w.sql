create
    definer = root@localhost procedure sp_deleteCustomer(IN acc_no int)
BEGIN
    DELETE FROM customers
    WHERE account_number = acc_no;

    -- Return how many rows were deleted (0 means not found)
    SELECT ROW_COUNT() AS affected_rows;
END;

