create
    definer = root@localhost procedure sp_deleteCustomer(IN p_account_number int)
BEGIN
    DELETE FROM customers WHERE account_number = p_account_number;
END;

